//: Playground - noun: a place where people can play
/*
 ylw: 245807668
 */

import UIKit

var xx:String?
    xx = "xxx"
    print("\(xx)")

var str = "Hello, playgroun"
    str += "d"
//    str = str + "d" + "c"
var tempNumber = 11
var int = 14

//字符串 string && NSString
extension String {
    public func indexOfCharacter(char: Character) -> Int? {
        if let idx = self.characters.indexOf(char) {
            return self.startIndex.distanceTo(idx)
        }
        return nil
    }
}
let length = str.characters.count
if (str as NSString).containsString("Hello") {
    print("true")
}
let index  = str.indexOfCharacter("p")

//截取字符串
var index1 = str.endIndex.advancedBy(-4)      //后面往前第4个
var substring1 = str.substringToIndex(index1) //取出index1之前的字符

let indexxx = str.startIndex.advancedBy(4)  //str 开始位置
let indexxx1 = str.endIndex.advancedBy(-6)  //结束位置
var range = Range(indexxx ..< indexxx1)     //获取一个Range
var s3 = str.substringWithRange(range)      //截取取出这个范围内的字符串

extension String {
    //返回从出现该字符之前的Index
    func indexOf(string: String) -> String.Index {
        return rangeOfString(string, options: .LiteralSearch, range: nil, locale: nil)?.startIndex ?? startIndex
    }
}
let domains2 = str.substringToIndex(str.indexOf("pl"))
//是否包含某个字符串
let iscontains = str.characters.contains("p")
if str.rangeOfString("pl") != nil {
  print(str.characters.indexOf("p")!)
}



//数组(Array)
  /*
 Swift的数组对它们能存放的值的类型是明确的。这不同于Objective-C的NSArray类和NSMutableArray类，Objective-C的数组能存储任何类型的对象，并且不提供关于这些对象自身的任何信息。在Swift里，任何一个特定的数组所能存储的值，其类型总会被确定下来，或者通过显式的类型说明，或者通过类型推断，并且该类型不必是类类型。例如，如果你创建了一个Int型数组，你就不能把任何非Int型的值插入这个数组。Swift数组是类型安全的，它总是知道它能存储什么值。
 */

   var  lifeList = ["yyy", "www"]              // lifeList = ["yyy", 1]
        lifeList.append("ylw")                 // lifeList += [1]  //shoppingList += ["1"]
        lifeList.removeAtIndex(0)
   let  iscontain = lifeList.contains("www")

//字典（Dictionary）
/*
        和Array 一样 数据类型是安全的
 */
    var lifeListDic = ["y": "ylw", "g": "gxj"]
        lifeListDic["w"] = "shanhhai"
        lifeListDic.updateValue("Paris", forKey: "y")   // shoppingListDic["y"] = "Paris"
        lifeListDic.removeValueForKey("y")

//枚举(enum)
    enum day: String{
        case 星期一 = "add",  星期二 = "sub"
    }
    let  x = day(rawValue: "add")

    enum week{
        case Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    }
    var todayweek = week.Friday
        todayweek = .Wednesday
    //可以存储不同类型的关联值
    enum Cardkind {
        case Bank(Int, Int)
        case Socialsecurity(String)
    }


//let temprange = NSMakeRange(1, 5)
////   str.stringByReplacingCharactersInRange(temprange, withString: "rrrr")

//Swtit
let indexOne = str.startIndex
let swiftRange = str.startIndex ..< indexOne.advancedBy(4)
    str.stringByReplacingCharactersInRange(swiftRange, withString: "r")


//OC
let temprange = NSMakeRange(1, 5)
    (str as NSString).stringByReplacingCharactersInRange(temprange, withString: "cccc")


//闭包
typealias add =  (a:Int,b:Int) -> ()

func xx (temp:add) {
    temp(a: tempNumber, b: int)
}
xx { (a, b) in
    print(a+b)
}

//分支 
   //switch 支持多种数据类型
var i = 15
switch i {
case 0 ... 10:   // ...
    "0~10"
case 11 ..< 20:  // ..<
    "11~20" //输出
default:
    "default"
}

 switch str {
    case "Hello, playground":
         tempNumber = 12
        fallthrough         //新关键字
     case "ylw":
        int = 0
    default:
         str
}

let response = (0,str)
switch response {
    case (0, let tempvalue) where tempvalue == "ylw":
          tempvalue
    case (int, _):
        "\(int)"      //被输出
      default:
         ""
    }

let request = (0,"success")
    switch request {
case (0, let state):
        state    //被输出:success
case (let errorCode, _):
        "error code is \(errorCode)"
}       // 涵盖了所有可能的case，不用写default了

var creatCard = Cardkind.Bank(622, 898)
    switch creatCard {
        case let .Bank(hax,last):
        print("\(hax),\(last)")        // 输出  "622,898"
    case let .Socialsecurity(cardnum):
        print(cardnum)
    }
//类和结构体
/*存储属性
 简单来说，一个存储属性就是存储在特定类或结构体的实例里的一个常量或变量，存储属性可以是变量存储属性（用关键字var定义），也可以是常量存储属性（用关键字let定义）
 
 计算属性
 除存储属性外，类、结构体和枚举可以定义计算属性，计算属性不直接存储值，而是提供一个 getter 来获取值，一个可选的 setter 来间接设置其他属性或变量的值。
 
 */

struct SomeStructure {
    static let storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 2
    }
}

class SomeClass {
    class var computedTypeProperty:String {
        return "Some value."
    }
    //class var computedTypeProperty1 = ""  // Class stored properties not yet supported in classes
    static var  computedTypeProperty1 = ""
}

//可以明白为什么有计算属性
struct Point {
    var x = 100.0, y = 200.0
}
struct Size {
    var width = 0.0, height = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set(newCenter) {
            origin.x = newCenter.x - (size.width / 2)
            origin.y = newCenter.y - (size.height / 2)
        }
    }
}
    Rect.init().center.x


// 继承
class SomeClass1 : SomeClass {

}
 SomeClass1.computedTypeProperty


for x in str.characters {
  print(x)
}

